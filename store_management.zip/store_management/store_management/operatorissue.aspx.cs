﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.Drawing;
using System.IO;
namespace store_management
{
    public partial class operatorissue : System.Web.UI.Page
    {
       // static Random random = new Random();
        Boolean flag=true;
        SqlConnection con = new SqlConnection();
        string cstr = ConfigurationManager.ConnectionStrings["sqlconstring"].ConnectionString;
        dbclass db = new dbclass();
        protected void Page_Load(object sender, EventArgs e)
        {
            Label3.Visible = true;
            Label4.Visible = true;
            Label7.Text = "";
            TextBox1.Text = "1";
            db.OpenConnection(cstr);
            long issue_no = db.allnewindents();
            TextBox5.Text = (issue_no + 1).ToString();
            db.CloseConnection();

            DateTime now = DateTime.Now;

            string date = DateTime.Today.ToString("dd-MM-yyyy");
            string time = DateTime.Now.ToString("HH:mm:ss");
            TextBox6.Text = date + time;
           // Label3.Text = "WELCOME";
            if (Session["usertype"].ToString() != "operator" && Session["usertype"].ToString() != "Administrator")
            {
                Response.Redirect("~/login.aspx");
                return;
            }
            TextBox7.Text= Session["username"].ToString();
            if (!IsPostBack)
            {
                RefreshGridView();
            }
            Panel4.Visible = false;
            Panel1.Visible = false;
            Label2.Text = "0";
           // Label3.Text = "";
            db.OpenConnection(cstr);
            Label2.Text=db.allnewindents().ToString();
            db.CloseConnection();
           
            }
        
        protected void RefreshGridView()
        {
            db.OpenConnection(cstr);
            DataTable dt = db.GetAllIndents();
            db.CloseConnection();

            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();

                GridView1.Visible = true;
                
            }
            else
            {
                GridView1.Visible = false;
               
            }
        }
        protected void getId()
        {

        }
        
        protected void fillitems()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=.\\sqlexpress;Initial Catalog=scestore;Integrated Security=sspi";
            con.Open();


            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select mstitem.id,mstitem.name,qty,remarks,lastid,itemid from Product_Indent inner join mstitem on itemid=mstitem.id where lastid="+long.Parse(TextBox1.ToolTip).ToString();
           // cmd.CommandText = "select name from mstitem";
            cmd.Connection = con;


            DataTable dt = new DataTable();
            SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            dr.Close();


            GridView2.DataSource = dt;
            GridView2.DataBind();

            con.Close();

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            //Label2.Text = "";
            //Label3.Text = "";
            Panel7.Visible = false;
            Panel6.Visible = false;
            foreach (GridViewRow r in GridView2.Rows)
            {
                System.Web.UI.WebControls.TextBox txt1 = new System.Web.UI.WebControls.TextBox();
                txt1 = (System.Web.UI.WebControls.TextBox)r.FindControl("issuedqty");
                System.Web.UI.WebControls.CheckBox chk = new System.Web.UI.WebControls.CheckBox();
                chk = (System.Web.UI.WebControls.CheckBox)r.FindControl("chkbox");
                
                    
                int requestedqty = int.Parse(r.Cells[3].Text);
                //long issued = long.Parse(r.Cells[4].Text);
                //long avlqty = (requestedqty - issued);
                if (chk.Checked && txt1.Text.Trim()!="")
                {
                    if (int.Parse(txt1.Text.Trim()) > requestedqty)
                    {
                        Panel4.Visible = true;
                        Label7.Text = "Issued quantity should be less than Requested  quantity";
                      
                        GridView1.Visible = true;
                        Panel3.Visible = false;
                        Panel2.Visible = false;
                        GridView2.Visible = false;
                       
                        flag = false;
                        break;
                    }
                    else
                    {
                        flag = true;

                    }

                }
            }
            if (flag == true)
            {
                GridView1.Visible = true;
                db.OpenConnection(cstr);
                long idnid = long.Parse(TextBox1.ToolTip);
                db.InsertIssueMaster(long.Parse(TextBox5.Text.Trim().ToString()), TextBox6.Text.Trim(), TextBox7.Text.Trim(), long.Parse(TextBox1.ToolTip));
                long lastid = db.GetIdOfIssueMaster();

                foreach (GridViewRow r in GridView2.Rows)
                {
                    long itemid = long.Parse(r.Cells[1].Text);
                    System.Web.UI.WebControls.TextBox txt = new System.Web.UI.WebControls.TextBox();
                    txt = (System.Web.UI.WebControls.TextBox)r.FindControl("issuedqty");
                    System.Web.UI.WebControls.CheckBox chk = new System.Web.UI.WebControls.CheckBox();
                    chk = (System.Web.UI.WebControls.CheckBox)r.FindControl("chkbox");

                    if (chk.Checked && txt.Text.Trim()!="")
                    {
                        //db.Product_Indent(txt.Text, txtre.Text, lastid, itemid);
                        db.InsertIssueDeatils(lastid, itemid, long.Parse(txt.Text.Trim()), idnid);




                        // MessageBox.Show("qty is" + txt.Text);
                        //db.CloseConnection();
                    }
                }
                Label5.Text = "Your Indent is Accepted and Available items Issued";
                db.UpdateIndentStatus(long.Parse(TextBox1.ToolTip), "Indent Accepted", "Accept");
                db.CloseConnection();

            }


        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            GridView1.Visible = true;
            Panel1.Visible = false;
            Panel2.Visible = false;
            Panel3.Visible = false;
            Panel4.Visible = false;
            Panel5.Visible = false;
            Panel7.Visible = false;
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void LinkButton5_Click(object sender, EventArgs e)
        {
            Panel7.Visible = false;
            //Label2.Text = "";
            //Label3.Text = "";
            //Label4.Text = "";
            Panel6.Visible = false;
            LinkButton lb = sender as LinkButton;
            GridViewRow row = (GridViewRow)lb.NamingContainer;
            GridView1.SelectedIndex = row.RowIndex;

            DataTable dt1 = new DataTable();
            DataTable dt = new DataTable();
            db.OpenConnection(cstr);
            dt = db.GetAllItemByidIndent(long.Parse(GridView1.SelectedDataKey.Value.ToString()));
            dt1 = db.checkStatus(long.Parse(GridView1.SelectedDataKey.Value.ToString()));
            db.CloseConnection();
            TextBox8.ToolTip = dt1.Rows[0][1].ToString();
            if (dt1.Rows[0][0].ToString().Trim() != "Accept")
            {
                TextBox1.Text = dt.Rows[0]["indent_no"].ToString();
                TextBox1.ToolTip = dt.Rows[0]["indent_id"].ToString();
                TextBox9.Text = dt.Rows[0]["indent_creator"].ToString();
                TextBox10.Text = dt.Rows[0]["indent_date"].ToString();
                TextBox4.Text = dt.Rows[0]["indent_reason"].ToString();
                // TextBox3.Text = dt.Rows[0]["indent_status"].ToString();
                Label2.ToolTip = "E";


                GridView1.Visible = false;
                Panel1.Visible = true;

                fillitems();
            }
            else
            {
                Panel4.Visible = true;
                Panel3.Visible = false;
                Panel2.Visible = false;
                GridView1.Visible = true;
                //Panel1.Visible = true;
                Label7.Text = "Indent already Accepted now it can't be again Accept";
            }
            
        }

        protected void LinkButton6_Click(object sender, EventArgs e)
        {
            Panel7.Visible = false;
            Panel6.Visible = false;
            LinkButton lb = sender as LinkButton;
            GridViewRow row = (GridViewRow)lb.NamingContainer;
            GridView1.SelectedIndex = row.RowIndex;

            DataTable dt = new DataTable();
            db.OpenConnection(cstr);
           
            dt = db.checkStatus(long.Parse(GridView1.SelectedDataKey.Value.ToString()));

            db.CloseConnection();
            TextBox8.ToolTip = dt.Rows[0][1].ToString();
            if (dt.Rows[0][0].ToString().Trim() != "Accept")
            {
                Panel3.Visible = true;
                Panel2.Visible = false;
                Panel4.Visible = false;
                GridView1.Visible = false;
            }
            else
            {
                Panel4.Visible = true;
                Panel3.Visible = false;
                Panel2.Visible = false;
                GridView1.Visible = true;
                Label7.Text = "Indent already accepted now it can't be rejected";
            }
            
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            //Panel7.Visible = false;
            db.OpenConnection(cstr);
            long lastid = long.Parse(TextBox8.ToolTip);
            db.UpdateIndentStatus(lastid, TextBox8.Text.Trim(), "Rejected");
            db.CloseConnection();
            Panel2.Visible = false;
            Panel3.Visible = false;
            Panel4.Visible = false;
            GridView1.Visible = true;
            Label7.Text = "Indent has been Rejected";


        }

        protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
        {
        
        }

        protected void TextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button10_Click(object sender, EventArgs e)
        {
            Panel6.Visible = true;
            Panel1.Visible = true;
            Panel2.Visible = false;
            Panel3.Visible = false;
            Panel4.Visible = false;
          //  Panel7.Visible = false;
            //if (!this.IsPostBack)
            //{
            string constr = ConfigurationManager.ConnectionStrings["sqlconstring"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT indent_no FROM product_indent1"))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = con;
                    con.Open();
                    DropDownList1.DataSource = cmd.ExecuteReader();
                    // DropDownList1.DataSource = cmd.ExecuteReader();
                    DropDownList1.DataTextField = "indent_no";
                    DropDownList1.DataValueField = "indent_no";
                    DropDownList1.DataBind();
                    con.Close();
                }
            }
            DropDownList1.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select Indent_no --", "0"));
        }
         
        protected void Button9_Click(object sender, EventArgs e)
        {
            Panel1.Visible = true;
            Panel2.Visible = false;
            Panel3.Visible = false;
            Panel4.Visible = false;
            Panel5.Visible = false;
            Panel6.Visible = true;
            Panel7.Visible = false;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=.\\sqlexpress;Initial Catalog=scestore;Integrated Security=sspi";
            con.Open();
            //string abc =(TextBox11.ToolTip).ToString();
            SqlCommand cmd = new SqlCommand();

            string strsql = "select indent_no,indent_creator,indent_date,issue_no,issue_date,issue_by,name,issueindentdetails.issuedqty,qty from product_indent1 inner join Product_Indent on product_indent1.indent_id=Product_Indent.idnid";
            strsql = strsql + " inner join mstitem on mstitem.id=Product_Indent.itemid inner join issueindentdetails on Product_Indent.idnid=issueindentdetails.idnid and Product_Indent.itemid=issueindentdetails.itemid inner join issuemaster on issuemaster.id=issueindentdetails.lastid and product_indent.itemid=issueindentdetails.itemid where product_indent1.indent_no=" + long.Parse(DropDownList1.SelectedItem.Value.Trim());
            cmd.CommandText = strsql;
             cmd.Connection = con;
            DataTable dt = new DataTable();
            SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            dr.Close();


            GridView4.DataSource = dt;
            GridView4.DataBind();
            if (GridView4.Rows.Count == 0)
            {
                Label7.Visible = true;
                Label7.Text = "NO RECORDS FOUND";
            }
            con.Close();

        }
        

        protected void Button7_Click(object sender, EventArgs e)
        {
            if (GridView4.Rows.Count > 0)
            {
                this.GridView4.AllowPaging = false;
                //this.GridView1.DataBind();
                RefreshGridView();
                GridViewExportUtil.Export("report_summ.xls", this.GridView4);
            }
        }

        protected void Button8_Click(object sender, EventArgs e)
        {

        }
        protected void Button11_Click(object sender, EventArgs e)
        {
           
        }
        

        protected void issuedqty_TextChanged(object sender, EventArgs e)
        {

        }
        protected void showreturn()
        {
            Panel7.Visible = true;
            GridView3.Visible = true;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=.\\sqlexpress;Initial Catalog=scestore;Integrated Security=sspi";
            con.Open();
            //string abc =(TextBox11.ToolTip).ToString();
            SqlCommand cmd = new SqlCommand();

            string strsql = "select mstitem.id,mstitem.name,qty,issueindentdetails.issuedqty,returnqty from Product_Indent left join issueindentdetails on Product_Indent.itemid=issueindentdetails.itemid and Product_Indent.idnid=issueindentdetails.idnid left join mstitem on Product_Indent.itemid=mstitem.id";
            strsql = strsql + " inner join ReturnItemDetails on ReturnItemDetails.idnid=issueindentdetails.idnid and ReturnItemDetails.itemid=issueindentdetails.itemid where ReturnItemDetails.idnid=" +long.Parse(TextBox1.ToolTip).ToString();
            cmd.CommandText = strsql;
            cmd.Connection = con;
            DataTable dt = new DataTable();
            SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            dr.Close();


            GridView3.DataSource = dt;
            GridView3.DataBind();
            if (GridView3.Rows.Count == 0)
            {
                Label11.Visible = true;
                Label11.Text = "0 ITEMS RETURNED";
            }
            con.Close();
        }
        protected void LinkButton7_Click(object sender, EventArgs e)
        {
           
            Panel7.Visible = true;
            GridView3.Visible = true;
            Panel2.Visible = false;
            GridView1.Visible = true;
            
            LinkButton lb = sender as LinkButton;
            GridViewRow row = (GridViewRow)lb.NamingContainer;
            GridView1.SelectedIndex = row.RowIndex;

            DataTable dt = new DataTable();
            db.OpenConnection(cstr);
            dt = db.GetAllItemByidIndent(long.Parse(GridView1.SelectedDataKey.Value.ToString()));
            db.CloseConnection();

            TextBox11.Text = dt.Rows[0]["indent_no"].ToString();
            TextBox1.ToolTip = dt.Rows[0]["indent_id"].ToString();
            TextBox13.Text = dt.Rows[0]["indent_date"].ToString();
            //TextBox12.Text = dt.Rows[0]["return_reason"].ToString();
            //TextBox14.Text = dt.Rows[0]["return_no"].ToString();
            //TextBox15.Text = dt.Rows[0]["return_date"].ToString();
            //TextBox16.Text = dt.Rows[0]["return_by"].ToString();
            // TextBox3.Text = dt.Rows[0]["indent_status"].ToString();
            Label2.ToolTip = "E";


            GridView1.Visible = true;
            Panel1.Visible = true;
            showreturn();
            
        }

        protected void Button11_Click1(object sender, EventArgs e)
        {
            if (GridView3.Rows.Count > 0)
            {
                this.GridView3.AllowPaging = false;
                //this.GridView1.DataBind();
                showreturn();
                GridViewExportUtil.Export("report_summ.xls", this.GridView3);
            }
        }

        

    }
}