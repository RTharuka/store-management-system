﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.Drawing;
using System.IO;

namespace store_management
{
    public partial class Demo : System.Web.UI.Page
    {
        static Random random = new Random();
        Boolean flag = true;
        SqlConnection con = new SqlConnection();
        string cstr = ConfigurationManager.ConnectionStrings["sqlconstring"].ConnectionString;
        dbclass db = new dbclass();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                RefreshGridView();
                fillitems();
            }
            Label9.Text = "";
            TextBox1.Text = "1";
            TextBox5.Text = "1";
            db.OpenConnection(cstr);
            long indent_no = db.IndentNo();
            
            TextBox1.Text = indent_no.ToString();
            
            long return_no = db.ReturnNo();
            TextBox5.Text = return_no.ToString();
           // TextBox1.Text = (indent_no + 1).ToString();
            
            db.CloseConnection();
            DateTime now = DateTime.Now;

            string date = DateTime.Today.ToString("dd-MM-yyyy");
            string time = DateTime.Now.ToString("HH:mm:ss");
            TextBox6.Text = TextBox2.Text = date + time;
            Label3.Text = "WELCOME";
            //Label9.Visible = false;

            TextBox7.Text = Label4.Text = txtContactsSearch.Text = Session["username"].ToString();

            if (Session["usertype"].ToString() != "Faculty" && Session["usertype"].ToString() != "Administrator")
            {
                Response.Redirect("~/login.aspx");
                return;
            }
            Label2.Text = "";
            Panel1.Visible = true;

            if (!this.IsPostBack)
            {
                RefreshGridView();
                fillitems();
            }
        }


        
        protected void fillitems()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=.\\sqlexpress;Initial Catalog=scestore;Integrated Security=sspi";
            con.Open();


            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select * from mstitem";
            cmd.Connection = con;


            DataTable dt = new DataTable();
            SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            dr.Close();


            GridView1.DataSource = dt;
            GridView1.DataBind();

            con.Close();

        }
        protected void RefreshGridView()
        {
            db.OpenConnection(cstr);
            DataTable dt = db.GetAllIndents();
            db.CloseConnection();

            if (dt.Rows.Count > 0)
            {
                GridView2.DataSource = dt;
                GridView2.DataBind();

                GridView2.Visible = true;
                Panel1.Visible = false;
            }
            else
            {
                GridView2.Visible = false;
                Panel1.Visible = true;
            }
        }
        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            Panel4.Visible = false;
            LinkButton lb = sender as LinkButton;
            GridViewRow row = (GridViewRow)lb.NamingContainer;
            GridView2.SelectedIndex = row.RowIndex;
            DataTable dt2 = new DataTable();

            DataTable dt = new DataTable();
            db.OpenConnection(cstr);
            dt2 = db.checkStatus(long.Parse(GridView2.SelectedDataKey.Value.ToString()));
            Label9.ToolTip = dt2.Rows[0][1].ToString();
            if (dt2.Rows[0][0].ToString().Trim() != "Accept" && dt2.Rows[0][0].ToString().Trim() != "Rejected")
            {
                dt = db.GetAllItemByidIndent(long.Parse(GridView2.SelectedDataKey.Value.ToString()));
                TextBox1.Text = dt.Rows[0]["indent_no"].ToString();
                TextBox1.ToolTip = dt.Rows[0]["indent_id"].ToString();
                txtContactsSearch.Text = dt.Rows[0]["indent_creator"].ToString();
                TextBox2.Text = dt.Rows[0]["indent_date"].ToString();
                TextBox4.Text = dt.Rows[0]["indent_reason"].ToString();
                Label2.ToolTip = "E";

                fillitems();
                DataTable dt1 = new DataTable();
                dt1 = db.GetIndentDetailRecords(long.Parse(GridView2.SelectedDataKey.Value.ToString()));
                for (int i = 0; i < dt1.Rows.Count; i++)
                {
                    foreach (GridViewRow r in GridView1.Rows)
                    {
                        long itemid = long.Parse(r.Cells[4].Text);
                        System.Web.UI.WebControls.TextBox txt = new System.Web.UI.WebControls.TextBox();
                        txt = (System.Web.UI.WebControls.TextBox)r.FindControl("txtqty");
                        System.Web.UI.WebControls.TextBox txtre = new System.Web.UI.WebControls.TextBox();
                        txtre = (System.Web.UI.WebControls.TextBox)r.FindControl("txtremarks");
                        System.Web.UI.WebControls.CheckBox chk = new System.Web.UI.WebControls.CheckBox();
                        chk = (System.Web.UI.WebControls.CheckBox)r.FindControl("chkbox");

                        if (itemid == long.Parse(dt1.Rows[i]["itemid"].ToString()))
                        {
                            chk.Checked = true;
                            txt.Text = dt1.Rows[i]["qty"].ToString();
                            txtre.Text = dt1.Rows[i]["remarks"].ToString();
                            break;
                        }
                    }
                }

                db.CloseConnection();
                GridView2.Visible = false;
                Panel1.Visible = true;
                Label9.Text = "";
            }
            else
            {
                Panel1.Visible = false;
                Panel3.Visible = false;
                Panel2.Visible = false;
                GridView1.Visible = false;
                GridView2.Visible = true;
                Label9.Text = "Indent already accepted now it can't be Edited";
            }
        }

        protected void LinkButton3_Click(object sender, EventArgs e)
        {
            Panel4.Visible = false;
            LinkButton lb = sender as LinkButton;
            GridViewRow row = (GridViewRow)lb.NamingContainer;
            GridView2.SelectedIndex = row.RowIndex;
            DataTable dt2 = new DataTable();


            db.OpenConnection(cstr);
            dt2 = db.checkStatus(long.Parse(GridView2.SelectedDataKey.Value.ToString()));
            Label9.ToolTip = dt2.Rows[0][1].ToString();
            if (dt2.Rows[0][0].ToString().Trim() != "Accept" && dt2.Rows[0][0].ToString().Trim() != "Rejected")
            {
                db.DeleteIndent(long.Parse(GridView2.SelectedDataKey.Value.ToString()));
                db.DeleteIndentDetail(long.Parse(GridView2.SelectedDataKey.Value.ToString()));
            }
            else
            {
                Panel1.Visible = false;
                Panel3.Visible = false;
                Panel2.Visible = false;
                GridView1.Visible = false;
                GridView2.Visible = true;
                Label9.Text = "Indent Can't Delete now It's ACCEPTED/REJECTED by Operator";
            }
            db.CloseConnection();


            RefreshGridView();
        }
      
        protected void Button1_Click(object sender, EventArgs e)
        {





            db.OpenConnection(cstr);

            if (Label2.ToolTip != "E")
            {
                //RequiredFieldValidator1.Enabled = true;
                db.PrepareIndent(TextBox1.Text.Trim(), txtContactsSearch.Text.Trim(), TextBox2.Text.Trim(), TextBox4.Text.Trim());
            }
            else
            {
                //RequiredFieldValidator1.Enabled = true;
                db.UpdateItemIndent(long.Parse(TextBox1.ToolTip.ToString()), TextBox1.Text.Trim(), txtContactsSearch.Text.Trim(), TextBox2.Text.Trim(), TextBox4.Text.Trim());
                db.DeleteIndentDetail(long.Parse(TextBox1.ToolTip));
            }
            // db.OpenConnection(cstr);
            long lastid = db.GetIdOfIndentmaster();
            foreach (GridViewRow r in GridView1.Rows)
            {
                long itemid = long.Parse(r.Cells[4].Text);
                long idnid = lastid;
                System.Web.UI.WebControls.TextBox txt = new System.Web.UI.WebControls.TextBox();
                txt = (System.Web.UI.WebControls.TextBox)r.FindControl("txtqty");
                System.Web.UI.WebControls.TextBox txtre = new System.Web.UI.WebControls.TextBox();
                txtre = (System.Web.UI.WebControls.TextBox)r.FindControl("txtremarks");
                System.Web.UI.WebControls.CheckBox chk = new System.Web.UI.WebControls.CheckBox();
                chk = (System.Web.UI.WebControls.CheckBox)r.FindControl("chkbox");

                if (chk.Checked && txt.Text.Trim() != "")
                {
                    db.Product_Indent(txt.Text, txtre.Text, lastid, itemid,idnid);
                    Label2.Text = "Indent succesfully Created";

                    //MessageBox.Show("Indent Successfully created");
                    //db.CloseConnection();
                }
            }
            db.CloseConnection();

            RefreshGridView();
            
            GridView2.Visible = true;
            Panel1.Visible = false;
            Panel5.Visible = true;
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Panel4.Visible = false;
            Panel1.Visible = true;
            GridView1.Visible = true;
            GridView2.Visible = false;
            GridView3.Visible = false;
            Panel3.Visible = false;
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            GridView2.Visible = true;
            Panel1.Visible = false;
            Panel2.Visible = false;
            Panel3.Visible = false;
            Panel4.Visible = false;
            Panel5.Visible = false;
        }



        protected void LinkButton4_Click(object sender, EventArgs e)
        {
            Panel1.Visible = false;
            GridView1.Visible = false;
            GridView2.Visible = false;
            Panel4.Visible = false;
        
            LinkButton lb = sender as LinkButton;
            GridViewRow row = (GridViewRow)lb.NamingContainer;
            GridView2.SelectedIndex = row.RowIndex;
            DataTable dt2 = new DataTable();
            DataTable dt = new DataTable();
            DataTable dt3 = new DataTable();
            db.OpenConnection(cstr);
            dt2 = db.checkStatus(long.Parse(GridView2.SelectedDataKey.Value.ToString()));
            dt3 = db.checkReturnStatus(long.Parse(GridView2.SelectedDataKey.Value.ToString()));
            Label9.ToolTip = dt2.Rows[0][1].ToString();
            Label6.ToolTip = dt3.Rows[0][1].ToString();
            if (dt2.Rows[0][0].ToString().Trim() == "Accept")
            {
                if (dt3.Rows[0][0].ToString().Trim() != "Returned")
                {
                    Panel3.Visible = true;
                    dt = db.GetAllItemByidIndent(long.Parse(GridView2.SelectedDataKey.Value.ToString()));
                    //db.CloseConnection();

                    TextBox11.Text = dt.Rows[0]["indent_no"].ToString();
                    TextBox11.ToolTip = dt.Rows[0]["indent_id"].ToString();
                    //txtContactsSearch.Text = dt.Rows[0]["indent_creator"].ToString();
                    TextBox10.Text = dt.Rows[0]["indent_date"].ToString();
                    //TextBox4.Text = dt.Rows[0]["indent_reason"].ToString();
                    // TextBox3.Text = dt.Rows[0]["indent_status"].ToString();
                    Label2.ToolTip = "E";

                    fillitemsreturn();


                    DataTable dt1 = new DataTable();
                    dt1 = db.GetIndentDetailRecords(long.Parse(GridView2.SelectedDataKey.Value.ToString()));



                    GridView2.Visible = false;
                    //Panel1.Visible = true;
                    db.CloseConnection();
                }
                else
                {
                    Panel1.Visible = false;
                    Panel3.Visible = false;
                    Panel2.Visible = false;
                    GridView1.Visible = false;
                    Label9.Text = "Items already returned once.";
                }
            }
            else
            {
                Panel1.Visible = false;
                Panel3.Visible = false;
                Panel2.Visible = false;
                GridView1.Visible = false;
                Label9.Text = "Indent not accepted yet.";
            }
            
        }
        protected void fillitemsreturn()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=.\\sqlexpress;Initial Catalog=scestore;Integrated Security=sspi";
            con.Open();
            //string abc =(TextBox11.ToolTip).ToString();
            SqlCommand cmd = new SqlCommand();
           
            string strsql = "select mstitem.id,mstitem.name,qty,issueindentdetails.issuedqty from Product_Indent left join issueindentdetails on Product_Indent.itemid=issueindentdetails.itemid and Product_Indent.idnid=issueindentdetails.idnid";
            strsql = strsql + " left join mstitem on Product_Indent.itemid=mstitem.id where Product_Indent.idnid=" + long.Parse(TextBox11.ToolTip).ToString();
            cmd.CommandText = strsql;
            cmd.Connection = con;
            DataTable dt = new DataTable();
            SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            dr.Close();


            GridView3.DataSource = dt;
            GridView3.DataBind();

            con.Close();

        }
        protected void Button6_Click(object sender, EventArgs e)
        {

        }

        protected void Button6_Click1(object sender, EventArgs e)
        {
        }

        protected void Button6_Click2(object sender, EventArgs e)
        {

            Panel4.Visible = false;
            foreach (GridViewRow r in GridView3.Rows)
            {
                //long itemid = long.Parse(r.Cells[1].Text);
                System.Web.UI.WebControls.TextBox txt = new System.Web.UI.WebControls.TextBox();
                txt = (System.Web.UI.WebControls.TextBox)r.FindControl("returnqty");
                System.Web.UI.WebControls.CheckBox chk1 = new System.Web.UI.WebControls.CheckBox();
                chk1 = (System.Web.UI.WebControls.CheckBox)r.FindControl("chkboxreturn");
                //long requestedqty = long.Parse(r.Cells[3].Text);
                long issued = long.Parse(r.Cells[4].Text);
                //long avlqty = (requestedqty - issued);
                if (chk1.Checked)
                {
                    if (long.Parse(txt.Text.Trim()) > issued)
                    {
                        Label9.Text = "Return quantity Should be less then issued quantity";
                        Label6.Text = ""; Label7.Text = ""; Label8.Text = "";
                        GridView1.Visible = false;
                        Panel3.Visible = false;
                        Panel1.Visible = false;
                        GridView2.Visible = false;
                        GridView3.Visible = false;
                        flag = false;
                        break;
                    }
                    else
                    {
                        flag = true;

                    }

                }
            }
            if(flag==true)
            {
            GridView1.Visible = false;
            GridView2.Visible = false;
            Panel1.Visible = false;
            Panel2.Visible = false;
            db.OpenConnection(cstr);
            
            long idnid=long.Parse(TextBox11.ToolTip);
            db.InsertReturnMaster(long.Parse(TextBox5.Text.Trim().ToString()), TextBox6.Text.Trim(),TextBox12.Text.Trim(), TextBox7.Text.Trim(), long.Parse(TextBox11.ToolTip));
            long lastid = db.GetIdOfReturnMaster();
            foreach (GridViewRow r in GridView3.Rows)
            {
                long itemid = long.Parse(r.Cells[1].Text);
                System.Web.UI.WebControls.TextBox txt = new System.Web.UI.WebControls.TextBox();
                txt = (System.Web.UI.WebControls.TextBox)r.FindControl("returnqty");
                System.Web.UI.WebControls.CheckBox chk1 = new System.Web.UI.WebControls.CheckBox();
                chk1 = (System.Web.UI.WebControls.CheckBox)r.FindControl("chkboxreturn");

                if (chk1.Checked)
                {


                    db.InserReturnDetails(itemid, lastid, long.Parse(txt.Text.Trim()),idnid);
                    Label6.Text = Session["username"].ToString();
                    Label7.Visible = true;
                    Label8.Visible = true;
                    Label6.Visible = true;

                }

            }
                 // MessageBox.Show("qty is" + txt.Text);
                    //db.CloseConnection();
                }
            
            //Label5.Text = "Your Indent is Accepted and Available items Issued";
            db.UpdateRetunStatus(long.Parse(TextBox11.ToolTip), "Items Returned", "Returned");
            db.CloseConnection();
        
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
           if (GridView4.Rows.Count > 0)
            {
                this.GridView4.AllowPaging = false;
                //this.GridView1.DataBind();
                RefreshGridView();
               GridViewExportUtil.Export("report_summ.xls", this.GridView4);
            }

        }
        //protected void RefreshGridViewpdf()
        //{
        //    try
        //    {
        //        con.Open();
        //        DataTable dt = new DataTable();
        //        dt = db.GetAllRequestedQty(DropDownList1.SelectedItem.Value.Trim());
        //        db.CloseConnection();
        //        GridView4.DataSource = dt;
        //        GridView4.DataBind();
             
        //    }
        //    catch (Exception ex)
        //    {
        //        Response.Write(ex.Message);
        //    }

        //}
        //protected void Button8_Click(object sender, EventArgs e)
        //{
        //    Panel4.Visible = true;
        //    Panel1.Visible = false;
        //    Panel2.Visible = false;
        //    Panel3.Visible = false;
        //    Panel5.Visible = false;
        //    if (GridView4.Rows.Count > 0)
        //    {

        //        using (StringWriter sw = new StringWriter())
        //        {

        //            using (HtmlTextWriter hw = new HtmlTextWriter(sw))
        //            {
        //                //To Export all pages
        //                GridView4.AllowPaging = false;
        //                this.RefreshGridViewpdf();

        //                GridView4.RenderControl(hw);
        //                StringReader sr = new StringReader(sw.ToString());
        //                Document pdfDoc = new Document(PageSize.A2, 10f, 10f, 10f, 0f);
        //                HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        //                PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        //                pdfDoc.Open();
        //                htmlparser.Parse(sr);
        //                pdfDoc.Close();

        //                Response.ContentType = "application/pdf";
        //                Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.pdf");
        //                Response.Cache.SetCacheability(HttpCacheability.NoCache);
        //                Response.Write(pdfDoc);
        //                Response.End();
        //            }
        //        }
        //    }
        //}

        protected void Button10_Click(object sender, EventArgs e)
        {
            Panel4.Visible = true;
            Panel1.Visible = false;
            Panel2.Visible = false;
            Panel3.Visible = false;
            Panel5.Visible = false;
            //if (!this.IsPostBack)
            //{
                string constr = ConfigurationManager.ConnectionStrings["sqlconstring"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constr))
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT indent_no FROM product_indent1"))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Connection = con;
                        con.Open();
                        DropDownList1.DataSource = cmd.ExecuteReader();
                       // DropDownList1.DataSource = cmd.ExecuteReader();
                        DropDownList1.DataTextField = "indent_no";
                        DropDownList1.DataValueField = "indent_no";
                        DropDownList1.DataBind();
                        con.Close();
                    }
                }
                DropDownList1.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select Indent_no --", "0"));
            }

        protected void Button9_Click(object sender, EventArgs e)
        {
            Panel4.Visible = true;
            Panel1.Visible = false;
            Panel2.Visible = false;
            Panel3.Visible = false;
            Panel5.Visible = false;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=.\\sqlexpress;Initial Catalog=scestore;Integrated Security=sspi";
            con.Open();
            //string abc =(TextBox11.ToolTip).ToString();
            SqlCommand cmd = new SqlCommand();

            string strsql = "select name,indent_no,indent_creator,indent_date,qty from product_indent1 inner join Product_Indent on product_indent1.indent_id=Product_Indent.idnid";
            strsql = strsql + " inner join mstitem on mstitem.id=Product_Indent.itemid where product_indent1.indent_no=" + long.Parse(DropDownList1.SelectedItem.Value.Trim());
            cmd.CommandText = strsql;
             cmd.Connection = con;
            DataTable dt = new DataTable();
            SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            dr.Close();


            GridView4.DataSource = dt;
            GridView4.DataBind();
            if (GridView4.Rows.Count == 0)
            {
                Label9.Visible = true;
                Label9.Text = "NO RECORDS FOUND";
            }

            con.Close();

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            
            RequiredFieldValidator3.Enabled = false;
            RequiredFieldValidator3.Visible = false;
            GridView2.Visible = true;
            Panel1.Visible = false;
            Panel2.Visible = false;
            Panel3.Visible = false;
            Panel4.Visible = false;
            Panel5.Visible = false;
        }

        protected void Button8_Click(object sender, EventArgs e)
        {

        }

       
       
        }
    }

        
            

        
    

        

     
    
