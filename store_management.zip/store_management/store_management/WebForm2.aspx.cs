﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sqlclient;
using System.Configuration;


namespace store_management
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        dbclass db = new dbclass();
        string c= Con
        protected void Page_Load(object sender, EventArgs e)
        {
            RefreshGridView();
        }
        protected void RefreshGridView()
        {
        }

        protected void Page_Load(object sender, System.EventArgs e)
        {
            return default(void);
        }

        protected void Button2_Click(object sender, System.EventArgs e)
        {
            return default(void);
        }

        protected void Button2_Click(object sender, System.EventArgs e)
        {
            return default(void);
        }

        protected void Button3_Click(object sender, System.EventArgs e)
        {
            return default(void);
        }

        protected void Button2_Click(object sender, System.EventArgs e)
        {
            return default(void);
        }
    }
}