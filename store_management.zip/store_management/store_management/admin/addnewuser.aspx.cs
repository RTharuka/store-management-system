﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace store_management.admin
{
    public partial class addnewuser : System.Web.UI.Page
    {
        string cstr = ConfigurationManager.ConnectionStrings["sqlconstring"].ConnectionString;
        dbclass db = new dbclass();
        protected void Page_Load(object sender, EventArgs e)
        {
            Label2.Text = "";
        }

        protected void Button2_Click(object sender, EventArgs e)
        {

          
        }

          protected void Button4_Click(object sender, EventArgs e)
          {
            db.OpenConnection(cstr);
            db.InsertUser(TextBox1.Text.Trim(), TextBox2.Text.Trim(), DropDownList1.SelectedItem.Value);

            db.CloseConnection();
            Label2.Text = "Successfully Created";
            TextBox1.Text = "";
            TextBox2.Text = "";
            DropDownList1.SelectedItem.Text = "";
            //Response.Redirect("admin.aspx");
        }

          protected void Button3_Click(object sender, EventArgs e)
          {
              TextBox1.Text = "";
              TextBox2.Text = "";
              DropDownList1.SelectedItem.Text="";
          }

          protected void Button2_Click1(object sender, EventArgs e)
          {
              Response.Redirect("admin.aspx");
          }

       

      
       

      
    }
}