﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
//using System.String;

namespace store_management.admin
{
    
    
    public partial class admin : System.Web.UI.Page
    {
        string cstr = ConfigurationManager.ConnectionStrings["sqlconstring"].ConnectionString;
        dbclass db = new dbclass();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            Label2.Text = "WELCOME";
            //Label3.ForeColor = "red";
            Label3.Text = Session["username"].ToString();
            if (Session["usertype"].ToString() != "Administrator")
            {
                Response.Redirect("~/login.aspx");
                return;
            }
            if (IsPostBack)
            {
                GridView1.Visible = false;
            }
            
        }

        protected void Button4_Click(object sender, EventArgs e)
        {

            GridView1.Visible = true;
            RefreshGridView();
        }
        protected void RefreshGridView()
        {
            db.OpenConnection(cstr);
            DataTable dt = db.GetAllUser();
            db.CloseConnection();

            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();

                GridView1.Visible = true;
               
            }
            else
            {
                GridView1.Visible = false;
             
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
        

        }

        protected void Button5_Click(object sender, EventArgs e)
        {

        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/operatorissue.aspx");
        }

        protected void LinkButton3_Click(object sender, EventArgs e)
        {
            LinkButton lb = sender as LinkButton;
            GridViewRow row = (GridViewRow)lb.NamingContainer;
            GridView1.SelectedIndex = row.RowIndex;


            db.OpenConnection(cstr);
            db.DeleteUser(long.Parse(GridView1.SelectedDataKey.Value.ToString()));
            db.CloseConnection();


            RefreshGridView();
        }

        protected void Button6_Click(object sender, EventArgs e)
        {

        }

        protected void Button3_Click(object sender, EventArgs e)
        {

        }

        
    }
}