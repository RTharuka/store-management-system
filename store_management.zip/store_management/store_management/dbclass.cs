﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace store_management
{

    public class dbclass
    {
        SqlConnection con = new SqlConnection();
        public void OpenConnection(string constr)
        {
            con.ConnectionString = constr;
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }


        
        public bool CheckLogin(string upassword, string utype,string username)
        {
            bool flag = true;
            SqlCommand cmd = new SqlCommand("select * from store_login where userpassword=@userpassword and usertype=@usertype and username=@username", con);
            cmd.Parameters.AddWithValue("@userpassword", upassword);
            cmd.Parameters.AddWithValue("@usertype", utype);
            cmd.Parameters.AddWithValue("@username", username);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                flag = true;
            }
            else
            {
                flag = false;

            }

            return flag;
        }

        public DataTable GetAllItems()
        {
            DataTable rdt = new DataTable();
            string sql = "select * from mstitem";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            rdt.Load(dr);
            dr.Close();
            return rdt;
        }
        public DataTable GetAllIndents()
        {
            DataTable rdt = new DataTable();
            string sql = "select * from product_indent1  order by indent_date DESC";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            rdt.Load(dr);
            dr.Close();
            return rdt;
        }
        public long allnewindents()
        {
            long indent_count;
            DataTable rdt = new DataTable();
            string sql = "select count(indent_id) from product_indent1";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            rdt.Load(dr);
            dr.Close();
            indent_count = long.Parse(rdt.Rows[0][0].ToString());
            return indent_count;
            
        }
        public long IndentNo()
        {
            long indent_count;
            DataTable rdt = new DataTable();
            string sql = "select TOP 1 indent_no from product_indent1 order by indent_no DESC";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            rdt.Load(dr);
            dr.Close();
            indent_count = long.Parse(rdt.Rows[0][0].ToString());
            return indent_count+1;

        }
        public long IssueNo()
        {
            long issue_count;
            DataTable rdt = new DataTable();
            string sql = "select TOP 1 issue_no from issuemaster order by issue_no DESC";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            rdt.Load(dr);
            dr.Close();
            issue_count = long.Parse(rdt.Rows[0][0].ToString());
            return issue_count + 1;

        }
        public long ReturnNo()
        {
            long return_count;
            DataTable rdt = new DataTable();
            string sql = "select TOP 1 return_no from returnmaster order by return_no DESC";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            rdt.Load(dr);
            dr.Close();
            return_count = long.Parse(rdt.Rows[0][0].ToString());
            return return_count + 1;

        }
        public DataTable GetAllUser()
        {
            DataTable rdt = new DataTable();
            string sql = "select * from store_login";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            rdt.Load(dr);
            dr.Close();
            return rdt;
        }
        public DataTable GetAllItemByid(long id)
        {
            DataTable rdt = new DataTable();
            string sql = "select * from mstitem where id=@id";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@id", id);
            SqlDataReader dr = cmd.ExecuteReader();
            rdt.Load(dr);
            dr.Close();
            return rdt;
        }
        public long GetIdOfIndentmaster()
        {
            long getindentid;
            DataTable rdt = new DataTable();
            string sql = string.Format("select max(indent_id) as lastid from product_indent1 ");
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            rdt.Load(dr);
            dr.Close();
            getindentid = long.Parse(rdt.Rows[0][0].ToString());
            return getindentid;
        }
        public DataTable GetAllRequestedQty(string indent_no)
        {


          DataTable detail= new DataTable();

          string strsql = "select name,indent_no,indent_creator,indent_date,qty from product_indent1 inner join Product_Indent on product_indent1.indent_id=Product_Indent.idnid";
          strsql = strsql + " inner join mstitem on mstitem.id=Product_Indent.itemid where indent_no=@indent_no";
          

            using (SqlCommand cmd = new SqlCommand(strsql, this.con))
            {
                cmd.CommandText = strsql;
                SqlDataReader dr = cmd.ExecuteReader();
                detail.Load(dr);
                dr.Close();

            }

            return detail;

        }
        public long GetIdOfIssueMaster()
        {
            long getissueid;
            DataTable rdt = new DataTable();
            string sql = string.Format("select max(id) as lastid from issuemaster ");
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            rdt.Load(dr);
            dr.Close();
            getissueid = long.Parse(rdt.Rows[0][0].ToString());
            return getissueid;
        }
        public long GetIdOfReturnMaster()
        {
            long getreturnid;
            DataTable rdt = new DataTable();
            string sql = string.Format("select max(id) as lastid from returnmaster ");
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            rdt.Load(dr);
            dr.Close();
            getreturnid = long.Parse(rdt.Rows[0][0].ToString());
            return getreturnid;
        }
        public DataTable GetAllItemByidIndent(long indent_id)
        {
            DataTable rdt = new DataTable();
            string sql = "select * from product_indent1 where indent_id=@indent_id";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@indent_id", indent_id);
            SqlDataReader dr = cmd.ExecuteReader();
            rdt.Load(dr);
            dr.Close();
            return rdt;
        }
        public DataTable checkStatus(long indent_id)
        {
            DataTable rdt = new DataTable();
            string sql = "select indent_status,indent_id from product_indent1 where indent_id=@indent_id";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@indent_id", indent_id);
            SqlDataReader dr = cmd.ExecuteReader();
            rdt.Load(dr);
            dr.Close();
            return rdt;
        }
        public DataTable checkReturnStatus(long indent_id)
        {
            DataTable rdt = new DataTable();
            string sql = "select return_status,indent_id from product_indent1 where indent_id=@indent_id";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@indent_id", indent_id);
            SqlDataReader dr = cmd.ExecuteReader();
            rdt.Load(dr);
            dr.Close();
            return rdt;
        }
        public DataTable GetIndentDetailRecords(long indent_id)
        {
            DataTable rdt = new DataTable();
            string sql = "select * from Product_Indent where lastid=@lastid";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@lastid", indent_id);
            SqlDataReader dr = cmd.ExecuteReader();
            rdt.Load(dr);
            dr.Close();
            return rdt;
        }
        public void InsertItem(string name, double price)
        {
            string sql = "insert into mstitem(name,price) values(@name,@price)";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@price", price);

            cmd.ExecuteNonQuery();

        }
        public void InsertUser(string username, string userpassword,string usertype)
        {
            string sql = "insert into store_login(username,userpassword,usertype) values(@username,@userpassword,@usertype)";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@username", username);
            cmd.Parameters.AddWithValue("@userpassword",userpassword);
            cmd.Parameters.AddWithValue("@usertype", usertype);
            cmd.ExecuteNonQuery();

        }
        public void DeleteItem(long id)
        {
            DataTable rdt = new DataTable();
            string sql = "delete from mstitem where id=@id";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@id", id);

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public void DeleteUser(long userid)
        {
            DataTable rdt = new DataTable();
            string sql = "delete from store_login where userid=@userid";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@userid", userid);

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public void DeleteIndent(long indent_id)
        {
            DataTable rdt = new DataTable();
            string sql = "delete from product_indent1 where indent_id=@indent_id";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@indent_id", indent_id);

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public void DeleteIndentDetail(long lastid)
        {
            DataTable rdt = new DataTable();
            string sql = "delete from Product_Indent where lastid=@lastid";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@lastid", lastid);
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public void PrepareIndent(string indent_no, string indent_creator,string indent_date, string indent_reason)
        {
            string sql = "insert into product_indent1(indent_no,indent_creator,indent_date,indent_reason,indent_status) values(@indent_no,@indent_creator,@indent_date,@indent_reason,'')";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@indent_no", indent_no);
            cmd.Parameters.AddWithValue("@indent_creator",indent_creator );
            cmd.Parameters.AddWithValue("@indent_date", indent_date);
            cmd.Parameters.AddWithValue("@indent_reason", indent_reason);
            //cmd.Parameters.AddWithValue("@indent_status", indent_status);
            cmd.ExecuteNonQuery();
        }
        public void UpdateItem(long id, string name, double price)
        {
            string sql = string.Format("update mstitem set name='{1}',price='{2}' where id={0}", id, name, price);
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();

        }
        public void UpdateItemIndent(long indent_id, string indent_no,string indent_creator, string indent_date,string indent_reason)
        {
            string sql = string.Format("update product_indent1 set indent_no='{1}',indent_creator='{2}',indent_date='{3}',indent_reason='{4}' where indent_id={0}", indent_id, indent_no, indent_creator,indent_date,indent_reason);
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();

        }
        public void UpdateIndentStatus(long indent_id, string remarks,string status)
        {
            string sql = string.Format("update product_indent1 set indent_status='{2}' , indent_reason='{1}' where indent_id={0}", indent_id,remarks,status);
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();

        }
        public void UpdateRetunStatus(long indent_id, string remarks, string status)
        {
            string sql = string.Format("update product_indent1 set return_status='{2}' , indent_reason='{1}' where indent_id={0}", indent_id, remarks, status);
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();

        }
       
        public Boolean checkDuplicateItem(string name)
        {
            DataTable rdt = new DataTable();
            string sql = string.Format("select * from mstitem where name=@name");
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@name", name);
           
            SqlDataReader dr = cmd.ExecuteReader();
            rdt.Load(dr);
            dr.Close();
            bool flag = false;

            if (rdt.Rows.Count == 1)
            {
                flag = true;
            }
            return flag;

        }

        public Boolean checkDuplicateItemEdit(string name,long id)
        {
            DataTable rdt = new DataTable();
            string sql = string.Format("select * from mstitem where name=@name and id!=@id");
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@name", name);
            SqlDataReader dr = cmd.ExecuteReader();
            rdt.Load(dr);
            dr.Close();
            bool flag = false;

            if (rdt.Rows.Count == 1)
            {
                flag = true;
            }
            return flag;

        }
        public void InsertIndentdetails(long mstid, long itemid,int qty, string remarks)
        {
            string sql = string.Format("insert into indentdetail(mstid,itemid,qty,remarks) values(@mstid,@itemid,@qty,@remarks)");
            SqlCommand cmd = new SqlCommand(sql,con);


            cmd.Parameters.AddWithValue("@qty", qty);
            cmd.Parameters.AddWithValue("@remarks", remarks);
            cmd.Parameters.AddWithValue("@mstid", mstid);
            cmd.Parameters.AddWithValue("@itemid", itemid);
           

                cmd.ExecuteNonQuery();
            }
        public void Product_Indent(string qty,string remarks,long lastid,long itemid,long idnid)
        {
            string sql = string.Format("insert into Product_Indent(qty,remarks,lastid,itemid,idnid) values(@qty,@remarks,@lastid,@itemid,@idnid)");
            SqlCommand cmd = new SqlCommand(sql, con);

            cmd.Parameters.AddWithValue("@qty", qty);
            cmd.Parameters.AddWithValue("@remarks", remarks);
            cmd.Parameters.AddWithValue("@lastid", lastid);
            cmd.Parameters.AddWithValue("@itemid", itemid);
            cmd.Parameters.AddWithValue("@idnid", idnid);
            cmd.ExecuteNonQuery();
        }
        public void InsertIssueMaster(long issue_no, string issue_date, string issue_by, long indent_id)
        {
            string sql = string.Format("insert into issuemaster(issue_no,issue_date,issue_by,indent_id) values(@issue_no,@issue_date,@issue_by,@indent_id)");
            SqlCommand cmd = new SqlCommand(sql, con);

            cmd.Parameters.AddWithValue("@issue_no", issue_no);
            cmd.Parameters.AddWithValue("@issue_date", issue_date);
            cmd.Parameters.AddWithValue("@issue_by", issue_by);
            cmd.Parameters.AddWithValue("@indent_id", indent_id);
            cmd.ExecuteNonQuery();
        }
        public void InsertIssueDeatils(long lastid, long itemid, long issuedqty,long idnid)
        {
            string sql = string.Format("insert into issueindentdetails(lastid,itemid,issuedqty,idnid) values(@lastid,@itemid,@issuedqty,@idnid)");
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@lastid", lastid);
            cmd.Parameters.AddWithValue("@itemid",itemid);
            
            cmd.Parameters.AddWithValue("@issuedqty", issuedqty);
            cmd.Parameters.AddWithValue("@idnid", idnid);
            cmd.ExecuteNonQuery();
        }
        public void InsertReturnMaster(long return_no, string return_date,string return_reason ,string return_by, long indent_id)
        {
            string sql = string.Format("insert into returnmaster(return_no,return_date,return_reason,return_by,indent_id) values(@return_no,@return_date,@return_reason,@return_by,@indent_id)");
            SqlCommand cmd = new SqlCommand(sql, con);

            cmd.Parameters.AddWithValue("@return_no", return_no);
            cmd.Parameters.AddWithValue("@return_date", return_date);
            cmd.Parameters.AddWithValue("@return_reason", return_reason);
            cmd.Parameters.AddWithValue("@return_by", return_by);
            cmd.Parameters.AddWithValue("@indent_id", indent_id);
            cmd.ExecuteNonQuery();
        }
        public void InserReturnDetails(long itemid, long lastid, long returnqty,long idnid)
        {
            string sql = string.Format("insert into ReturnItemDetails(itemid,lastid,returnqty,idnid) values(@itemid,@lastid,@returnqty,@idnid)");
            SqlCommand cmd = new SqlCommand(sql, con);

            cmd.Parameters.AddWithValue("@itemid", itemid);
            cmd.Parameters.AddWithValue("@lastid", lastid);
            cmd.Parameters.AddWithValue("@returnqty", returnqty);
            cmd.Parameters.AddWithValue("@idnid", idnid);
            cmd.ExecuteNonQuery();
        }
        }

    }
