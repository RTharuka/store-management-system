﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace store_management
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        static Random random = new Random();
        protected void Page_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < 2; i++)
            {

                TextBox1.Text = "" + (Convert.ToString(random.Next(1100, 50200))); // to specify range for random number
            }

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
           
        }
    }
}