﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace store_management
{
    public partial class login : System.Web.UI.Page
    {
        string cstr=ConfigurationManager.ConnectionStrings["sqlconstring"].ConnectionString;
        dbclass db = new dbclass();

        protected void Page_Load(object sender, EventArgs e)
        {
           
            Label1.Text = "";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session["username"] = TextBox1.Text;
            Label1.Text = "";
            db.OpenConnection(cstr);
            bool b = db.CheckLogin(TextBox2.Text.Trim(), DropDownList1.Text.Trim(), TextBox1.Text.Trim());
            db.CloseConnection();

            if (b == true)
            {

                Session["Administrator"] = "";
                Session["operator"] = "";
                Session["faculty"] = "";
                if (DropDownList1.SelectedItem.Text == "Administrator")
                {
                    Session["usertype"] = "Administrator";
                    Response.Redirect("admin/admin.aspx");
                }
                else if (DropDownList1.SelectedItem.Text == "Operator")
                {
                    Session["usertype"] = "operator";
                    Response.Redirect("operatorissue.aspx");
                }
                else
                {
                    Session["usertype"] = "Faculty";
                    Response.Redirect("IndentPrepare.aspx");
                }
            }
            else
            {
                Label1.Text = "Invalid user name or password";
            }
            
            
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
        }
    }
}