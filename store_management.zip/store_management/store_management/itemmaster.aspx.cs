﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;


namespace store_management
{
    public partial class itemmaster : System.Web.UI.Page
    {
        string cstr=ConfigurationManager.ConnectionStrings["sqlconstring"].ConnectionString;
        dbclass db = new dbclass();
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (Session["usertype"].ToString() != "Administrator")
            {
                Response.Redirect("login.aspx");
                return;
            }

            Label2.Text = "";
            TextBox3.ToolTip = "";
            if (!IsPostBack)
            {
                 RefreshGridView();
            }
        }
        protected void RefreshGridView()
        {
            db.OpenConnection(cstr);
            DataTable dt = db.GetAllItems();
            db.CloseConnection();

            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();

                GridView1.Visible = true;
                Panel1.Visible = false;
            }
            else
            {
                GridView1.Visible = false;
                Panel1.Visible = true;
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Panel1.Visible = true;
            GridView1.Visible = false;

            TextBox1.Focus();
            Label2.ToolTip = "";
            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text == "" && TextBox3.Text == "")
            {
                Label2.Text = "Product Name and Price is Manditory";
            }
            else
            {

                db.OpenConnection(cstr);



                if (Label2.ToolTip != "E")
                {
                    if (db.checkDuplicateItem(TextBox1.Text) == false)
                    {
                        db.InsertItem(TextBox1.Text.Trim(), double.Parse(TextBox3.Text.Trim()));
                    }
                    else
                    {
                        Label2.Text = "Record already exists";
                        db.CloseConnection();
                        return;
                    }
                }
                else
                {

                    if (db.checkDuplicateItemEdit(TextBox1.Text, long.Parse(TextBox1.ToolTip)) == false)
                    {

                        db.UpdateItem(long.Parse(TextBox1.ToolTip), TextBox1.Text, double.Parse(TextBox3.Text));
                    }
                    else
                    {
                        Label2.Text = "Record already exists";
                        db.CloseConnection();
                        return;
                    }
                }
                db.CloseConnection();


                Label2.Text = "Record Inserted Succesfully";


                RefreshGridView();
                Panel1.Visible = false;
                GridView1.Visible = true;
            }
        }


        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            LinkButton lb = sender as LinkButton;
            GridViewRow row = (GridViewRow)lb.NamingContainer;
            GridView1.SelectedIndex = row.RowIndex;

            DataTable dt= new DataTable();
            db.OpenConnection(cstr);
            dt=db.GetAllItemByid(long.Parse(GridView1.SelectedDataKey.Value.ToString()));
            db.CloseConnection();

            TextBox1.Text = dt.Rows[0]["name"].ToString();
            TextBox1.ToolTip = dt.Rows[0]["id"].ToString();
            TextBox3.Text = dt.Rows[0]["price"].ToString();

            Label2.ToolTip = "E";


            GridView1.Visible = false;
            Panel1.Visible = true;

        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            LinkButton lb = sender as LinkButton;
            GridViewRow row = (GridViewRow)lb.NamingContainer;
            GridView1.SelectedIndex = row.RowIndex;


            db.OpenConnection(cstr);
            db.DeleteItem(long.Parse(GridView1.SelectedDataKey.Value.ToString()));
            db.CloseConnection();


            RefreshGridView();

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
           /// TextBox3.Text = "";
            TextBox3.Text = "";
            Panel1.Visible = true;
            GridView1.Visible = false;

        }
    }
}