﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
namespace store_management
{
    public partial class indent : System.Web.UI.Page
    {
        string cstr = ConfigurationManager.ConnectionStrings["sqlconstring"].ConnectionString;
        dbclass db=new dbclass();
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Text = "";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
        }
    }
}